<template>
	<div>
		<h3 class="title is-3 has-text-info">About This Puzzle</h3>
	    <div class="notification">
	    	<p class="has-text-justified">The Mayans used a base-20 system for calculating large numbers, and that system used a combination of 0s (shell), 1s (dot), and 5s (bar). They also would count vertically, with the next higher block being a 20x increase. The first block is face value of dots/bars/shell, the second block would be 20 times its combination of dots and bars. The third block, 20 times 20 times larger.</p>
	    	<p>For more information, you can read <a href="https://www.storyofmathematics.com/mayan.html" target="_blank">The Story of Mathematics</a></p>
	    </div>
	</div>
</template>

<script>
    export default {
        
    }
</script>