<template>
    <div>
        <h3 class="title is-3 has-text-info">How to Play</h3>
        <div class="notification">
            <ol class="has-text-justified">
                <li>Clicking any of the four buttons randomly generates the number you will have to solve</li>
                <li>You have three possible options of counting blocks. <strong>Hint:</strong> the shell cannot be combined with any other one</li>
                <li>You drag and drop your selections from #2 into any of the dashed boxes. If you have to use multiple boxes remember that the higher a box is stacked the higher it's multiplied value is.</li>
                <li>When you are satisfied with your selections in #3 you can submit your answer. This will determine if your combination of counting blocks is accurate, and keeps track of your overall score.</li>
            </ol>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>