<template>
    <div class="modal modal-login">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Log In!</p>
            </header>
            <form @submit.prevent="submitLogin()" id="loginForm">
                <section class="modal-card-body">
                    <div class="field">
                        <label class="label" for="email">Username</label>
                        <div class="control has-icons-left has-icons-right">
                            <input class="input" type="email" name="email" id="email" placeholder="Your @ here" v-model.lazy.trim="loginData.email" />
                            <span class="icon is-small is-left">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <!--
                            <span class="icon is-small is-right">
                                <i class="fas fa-exclamation-triangle"></i>
                            </span>
                            -->
                        </div>
                    </div>
                    <div class="field">
                        <label class="label" for="password">Password</label>
                        <div class="control has-icons-left has-icons-right">
                            <input class="input" type="password" name="password" id="password" v-model.lazy.trim="loginData.password" />
                            <span class="icon is-small is-left">
                                <i class="far fa-eye"></i>
                            </span>
                        </div>
                    </div>
                </section>
                <footer class="modal-card-foot">
                    <div class="field is-grouped">
                        <p class="control">
                            <button class="button is-success">Login</button>
                        </p>
                        <p class="control">
                            <button class="button is-info modal-login-close">Close</button>
                        </p>
                    </div>
                </footer>
            </form>
            <button class="modal-close modal-login-close is-large" aria-label="close"></button>
        </div>
    </div>
</template>

<script>
    import { eventBus } from './main';

    export default {
        data() {
            return {
                loginData: {
                    email: '',
                    password: ''
                }
            }
        },
        computed: {
           
        },
        methods: {
            submitLogin() {
                //console.log(this.loginData.email);
                eventBus.$emit('loggedIn', {
                  loggedIn: true
                });
            }
        }
    }

</script>