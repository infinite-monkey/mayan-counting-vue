<template>
	<div>
	    <h3 class="title is-3 has-text-danger">Not Found</h3>
	    <p>Oops! You should have made a left turn at Alberquerque.</p>
	</div>
</template>